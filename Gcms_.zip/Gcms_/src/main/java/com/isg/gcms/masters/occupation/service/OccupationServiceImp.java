package com.isg.gcms.masters.occupation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.dao.OccupationDao;

import com.isg.gcms.masters.occupation.model.Occupation;

@Service
public class OccupationServiceImp implements OccupationService
{
	@Autowired
	private OccupationDao odao;
	
	@Autowired
	private ResponseObj res;

	@Override
	public ResponseObj getAllValues() {
		List<Occupation> values = this.odao.findAll();
		if(!values.isEmpty())
		{
			res.addData("Fetched all data", values);
		}
		else
		{
			res.setActionError("Occupation list not found");
		}
		return res;
		
	}

	@Override
	public ResponseObj create(@RequestBody Occupation occupation) {
		occupation.setCertified(1);
		Occupation occu=this.odao.save(occupation);
		res.addData("Save Occupation", occu );
		return res;
	}

	@Override
	public ResponseObj delete(Long id, Occupation occupation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseObj getById(Long id) {
		
		Optional<Occupation> occupation = this.odao.findById(id);
		if(occupation.isPresent())
		{
			res.addData("Requested value", occupation);
		}
		else
		{
			res.setActionError("Id not found");
		}
		return res;
	}

	

	@Override
	public ResponseObj findByName(String username) {
		List<Occupation> occupation = this.odao.findByuserName(username);
		if(!occupation.isEmpty())
		{
			res.addData("list of names are fetched", occupation);
		}
		else
		{
			res.setActionError("name not found");
		}
		return res;
	}

	@Override
	public ResponseObj updateVal(Long id, Occupation occupation) {
		// TODO Auto-generated method stub
		return null;
	}

}

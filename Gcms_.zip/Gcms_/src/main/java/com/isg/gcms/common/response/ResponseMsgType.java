package com.isg.gcms.common.response;

// Enumeration to define the Response Message Types
public enum ResponseMsgType
{

	SUCCESS, INFO, WARNING, ERROR;

}

package com.isg.gcms.common.response;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.gcms.utils.PropertyUtils;

@Component
@Scope(scopeName = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
@JsonAutoDetect(fieldVisibility = Visibility.NONE, setterVisibility = Visibility.NONE, getterVisibility = Visibility.NONE, isGetterVisibility = Visibility.NONE, creatorVisibility = Visibility.NONE)
@JsonInclude(value = Include.NON_NULL)
public class ResponseObj
{

	private Map<String, Object> data;

	private ValidationError validationError;

	private ResponseMsg msg;

	public ResponseObj()
	{
		super();
	}

	/* To add data with key and value */
	public void addData(String key, Object value)
	{
		if (data == null)
			data = new HashMap<>();
		data.put(key, value);
	}

	// Setters
	public void setMsg(String message, ResponseMsgType type)
	{
		if (message.startsWith("${") && message.endsWith("}"))
			message = PropertyUtils.getProperty(message.substring(2, message.length() - 1));

		msg = new ResponseMsg(message, type);
	}

	public void addFieldError(String fieldPath, String message)
	{
		if (validationError == null)
			validationError = new ValidationError();
		validationError.addFieldError(fieldPath, message);
	}

	public void setActionError(String error)
	{
		if (validationError == null)
			validationError = new ValidationError();
		validationError.setActionError(error);
	}

	public void setValidationError(ValidationError validationError)
	{
		this.validationError = validationError;
	}

	// GETTERS
	@JsonProperty
	public Map<String, Object> getData()
	{
		return data;
	}

	@JsonProperty
	public ValidationError getValidationError()
	{
		return validationError;
	}

	@JsonProperty
	public ResponseMsg getMsg()
	{
		return msg;
	}

	@Override
	public String toString()
	{
		return String.format("{msg=%s,validationError=%s,data=%s}", msg, validationError, data);
	}

}

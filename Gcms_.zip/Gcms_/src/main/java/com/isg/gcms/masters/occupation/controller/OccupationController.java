package com.isg.gcms.masters.occupation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.occupation.service.OccupationService;

@RestController
public class OccupationController 
{
	@Autowired
	private OccupationService service;
	
	@RequestMapping(value = "/allvalues" , method = RequestMethod.GET )
	public ResponseObj getall()
	{
		return service.getAllValues();
	}
	
	@PostMapping( value = "/create") 
	public ResponseObj create(@RequestBody Occupation occupation)
	{
		
		return this.service.create(occupation) ;
	}
	
	@GetMapping(  value = "/getvalue/{id}")
	public ResponseObj getValue(@PathVariable("id") Long id)
	
	{
		System.out.println(id);
		return service.getById(id);
	}

}

package com.isg.gcms.masters.occupation.service;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.model.Occupation;

@Service
public interface OccupationService 
{
	public ResponseObj getAllValues();
	
	public ResponseObj create(Occupation occupation);
	
	public ResponseObj delete(Long id ,  Occupation occupation);
	
	public ResponseObj getById(Long id);

	
	
	public  ResponseObj findByName(String username);

	public ResponseObj updateVal(Long id, Occupation occupation);
	
}

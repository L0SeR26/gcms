package com.isg.gcms.masters.occupation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;



@Entity
@Table(name = "GCMS_OCCUPATION")
@Data
public class Occupation
{
	@Id
	private Long occupationId;
	@Column
	private int bankId;
	@Column
	private String occupation;
	@Column
	private String occupationDesc;
	@Column
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String createdOn;
	@Column
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String modifiedOn;
	@Column
	private String userName;
	@Column
	private int active;
	@Column
	private String checker;
	@Column
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String checkerDate;
	@Column
	private int certified;

}
